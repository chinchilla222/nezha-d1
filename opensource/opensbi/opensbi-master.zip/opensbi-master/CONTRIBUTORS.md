
List of OpenSBI Contributors (Alphabetically sorted)
====================================================

* **[Western Digital Corporation](https://www.wdc.com/)**
  * Project initiator and maintainer
  * Copyright (c) 2019 Western Digital Corporation or its affiliates

* Alistair Francis <alistair@alistair23.me>

* Andreas Schwab <schwab@suse.de>

* Anup Patel <anup.patel@wdc.com>

* Atish Patra <atish.patra@wdc.com>

* Bin Meng <bmeng.cn@gmail.com>

* Damien Le Moal <damien.lemoal@wdc.com>

* Karsten Merker <merker@debian.org>

* Nick Kossifidis <mickflemm@gmail.com>

* Shawn Chang <citypw@gmail.com>

* Xiang Wang <wxjstz@126.com>
